"use strict";

{
  var abc = "ABC";
  console.log("main dadada");
}
"use strict";

{
  console.log("other");
  var abc = "XYZ";
}